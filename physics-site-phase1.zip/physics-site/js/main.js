/*
  PhysicsPath — main.js
  Renders the semester/module cards on the homepage using the data
  in js/data/physics-syllabus.js. Kept deliberately simple (no
  frameworks) so it's easy to read and extend in later phases.
*/

function renderSemesterGrid() {
  const grid = document.getElementById("semester-grid");
  if (!grid || typeof PHYSICS_SYLLABUS === "undefined") return;

  grid.innerHTML = PHYSICS_SYLLABUS.map(module => `
    <a class="semester-card" href="syllabus.html#${module.id}">
      <h3>${module.title}</h3>
      <p>${module.semesterLabel} · ${module.topics.length} topics</p>
    </a>
  `).join("");
}

document.addEventListener("DOMContentLoaded", renderSemesterGrid);
